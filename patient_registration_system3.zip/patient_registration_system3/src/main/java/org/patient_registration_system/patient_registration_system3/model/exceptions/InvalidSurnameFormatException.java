package org.patient_registration_system.patient_registration_system3.model.exceptions;

public class InvalidSurnameFormatException extends Exception {
    public InvalidSurnameFormatException(String message) {
        super(message);
    }
}

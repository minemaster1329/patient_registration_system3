package org.patient_registration_system.patient_registration_system3.model.exceptions;

public class InvalidPESELChecksumException extends Exception {
    public InvalidPESELChecksumException(String message) {
        super(message);
    }
}

package org.patient_registration_system.patient_registration_system3.model.exceptions;

public class InvalidEmailFormatException extends Exception {
    public InvalidEmailFormatException(String message) {super(message);}
}

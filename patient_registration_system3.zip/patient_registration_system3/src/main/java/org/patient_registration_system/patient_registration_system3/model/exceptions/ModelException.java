package org.patient_registration_system.patient_registration_system3.model.exceptions;

public class ModelException extends Exception{
    public ModelException(String message) {
        super(message);
    }
}

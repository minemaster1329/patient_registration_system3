package org.patient_registration_system.patient_registration_system3.model.data_models;

public enum Gender {
    Male,
    Female,
    Unknown
}

package org.patient_registration_system.patient_registration_system3.model.exceptions;

public class InvalidPESELFormatException extends Exception {
    public InvalidPESELFormatException(String message) {
        super(message);
    }
}

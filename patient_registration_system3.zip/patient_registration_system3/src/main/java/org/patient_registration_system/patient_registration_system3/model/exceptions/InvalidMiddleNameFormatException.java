package org.patient_registration_system.patient_registration_system3.model.exceptions;

public class InvalidMiddleNameFormatException extends Exception {
    public InvalidMiddleNameFormatException(String message) {
        super(message);
    }
}

package org.patient_registration_system.patient_registration_system3.model.exceptions;

public class InvalidNameFormatException extends Exception {
    public InvalidNameFormatException(String message) {super(message);}
}
